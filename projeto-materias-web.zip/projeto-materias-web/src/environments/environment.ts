
export const environment = {
    baseUrl: 'http://localhost:8000/api/'
}