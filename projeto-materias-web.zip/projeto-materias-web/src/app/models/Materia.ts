export interface Materia{

    id?: string;
    titulo: string;
    descricao: string; 
    texto_completo?: string;
    imagem: string;
    data_de_publicacao: string;
}